(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[29],{

/***/ 2886:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { BigNumber, BigNumberish } from \"@ethersproject/bignumber\";\nexport declare function commify(value: string | number): string;\nexport declare function formatUnits(value: BigNumberish, unitName?: string | BigNumberish): string;\nexport declare function parseUnits(value: string, unitName?: BigNumberish): BigNumber;\nexport declare function formatEther(wei: BigNumberish): string;\nexport declare function parseEther(ether: string): BigNumber;\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-units-lib-index-d-ts.0.23.2.1650712939442.js.map
//# sourceMappingURL=raw-loader!-ethersproject-units-lib-index-d-ts.0.23.2.1650712939442.js.map