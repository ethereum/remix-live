(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[70],{

/***/ 3280:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { Network, Networkish } from \"./types\";\nexport { Network, Networkish };\n/**\n *  getNetwork\n *\n *  Converts a named common networks or chain ID (network ID) to a Network\n *  and verifies a network is a valid Network..\n */\nexport declare function getNetwork(network: Networkish): Network;\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-networks-lib-index-d-ts.0.26.3.1662462205913.js.map
//# sourceMappingURL=raw-loader!-ethersproject-networks-lib-index-d-ts.0.26.3.1662462205913.js.map