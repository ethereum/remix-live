(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[32],{

/***/ 2889:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("import { logger, Wordlist } from \"./wordlist\";\nimport { wordlists } from \"./wordlists\";\nexport { logger, Wordlist, wordlists };\n//# sourceMappingURL=index.d.ts.map");

/***/ })

}]);
//# sourceMappingURL=raw-loader!-ethersproject-wordlists-lib-index-d-ts.0.23.0.1649931287389.js.map
//# sourceMappingURL=raw-loader!-ethersproject-wordlists-lib-index-d-ts.0.23.0.1649931287389.js.map